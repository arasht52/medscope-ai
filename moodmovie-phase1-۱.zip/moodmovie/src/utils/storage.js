// Low-level localStorage access.
// This is the ONLY module in the app allowed to touch window.localStorage directly.
// Components and hooks must never import this file — they go through services/.
//
// Safe by design for environments where window/localStorage is unavailable or
// throws (SSR, private/incognito browsing in some browsers, disabled storage,
// quota errors, etc.) — every exported function degrades gracefully instead
// of throwing.

let cachedAvailability = null;

/**
 * Check whether window.localStorage exists and is actually usable
 * (some browsers expose the API but throw on access, e.g. private mode).
 * Result is cached after the first check.
 * @returns {boolean}
 */
function isStorageAvailable() {
  if (cachedAvailability !== null) return cachedAvailability;

  try {
    if (typeof window === "undefined" || !window.localStorage) {
      cachedAvailability = false;
      return cachedAvailability;
    }

    const testKey = "__moodmovie_storage_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    cachedAvailability = true;
  } catch (error) {
    cachedAvailability = false;
  }

  return cachedAvailability;
}

/**
 * Read and JSON-parse a value from localStorage.
 * Returns `fallback` if storage is unavailable, the key is missing, or
 * parsing fails.
 * @param {string} key
 * @param {*} fallback
 * @returns {*}
 */
export function getItem(key, fallback = null) {
  if (!isStorageAvailable()) return fallback;

  try {
    const raw = window.localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw);
  } catch (error) {
    console.error(`storage.getItem failed for key "${key}":`, error);
    return fallback;
  }
}

/**
 * JSON-stringify and write a value to localStorage.
 * Returns false without throwing if storage is unavailable or the write fails.
 * @param {string} key
 * @param {*} value
 * @returns {boolean} whether the write succeeded
 */
export function setItem(key, value) {
  if (!isStorageAvailable()) return false;

  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`storage.setItem failed for key "${key}":`, error);
    return false;
  }
}

/**
 * Remove a key from localStorage.
 * Returns false without throwing if storage is unavailable or the removal fails.
 * @param {string} key
 * @returns {boolean} whether the removal succeeded
 */
export function removeItem(key) {
  if (!isStorageAvailable()) return false;

  try {
    window.localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error(`storage.removeItem failed for key "${key}":`, error);
    return false;
  }
}

/**
 * Check whether a key exists in localStorage.
 * Returns false if storage is unavailable.
 * @param {string} key
 * @returns {boolean}
 */
export function hasItem(key) {
  if (!isStorageAvailable()) return false;

  try {
    return window.localStorage.getItem(key) !== null;
  } catch (error) {
    console.error(`storage.hasItem failed for key "${key}":`, error);
    return false;
  }
}
