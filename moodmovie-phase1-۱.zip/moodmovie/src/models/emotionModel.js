// Canonical "vector" shape used for both emotion vectors and personality vectors
// throughout the app (e.g. { calm: 0.7, anxious: 0.1, excited: 0.2 }).
// Dimension names come from emotionalStates.json / personalityArchetypes.json
// (added in a later phase) — this module only enforces the generic shape rules:
// keys are non-empty strings, values are finite numbers between 0 and 1.

/**
 * Build a vector object from raw entries, coercing values to numbers and
 * dropping any entry that is not a finite number in the [0, 1] range.
 * @param {Object<string, number>} entries
 * @returns {Object<string, number>}
 */
export function createVector(entries = {}) {
  const vector = {};

  if (entries && typeof entries === "object") {
    for (const [key, rawValue] of Object.entries(entries)) {
      const value = Number(rawValue);
      if (typeof key === "string" && key.length > 0 && Number.isFinite(value)) {
        vector[key] = Math.min(1, Math.max(0, value));
      }
    }
  }

  return vector;
}

/**
 * Validate that a value conforms to the vector shape.
 * @param {*} vector
 * @returns {boolean}
 */
export function isValidVector(vector) {
  if (!vector || typeof vector !== "object" || Array.isArray(vector)) {
    return false;
  }

  return Object.entries(vector).every(([key, value]) => {
    return (
      typeof key === "string" &&
      key.length > 0 &&
      typeof value === "number" &&
      Number.isFinite(value) &&
      value >= 0 &&
      value <= 1
    );
  });
}

/**
 * Scale a vector's values so they sum to 1. Returns the original vector
 * unchanged if it is empty or its values sum to 0.
 * @param {Object<string, number>} vector
 * @returns {Object<string, number>}
 */
export function normalizeVector(vector) {
  if (!isValidVector(vector)) {
    throw new TypeError("normalizeVector: invalid vector shape");
  }

  const total = Object.values(vector).reduce((sum, value) => sum + value, 0);
  if (total <= 0) return { ...vector };

  const normalized = {};
  for (const [key, value] of Object.entries(vector)) {
    normalized[key] = value / total;
  }
  return normalized;
}

/**
 * Combine two vectors into one using weighted averaging over the union of keys.
 * Missing keys in either vector are treated as 0.
 * @param {Object<string, number>} vectorA
 * @param {Object<string, number>} vectorB
 * @param {number} weightA
 * @param {number} weightB
 * @returns {Object<string, number>}
 */
export function mergeVectors(vectorA, vectorB, weightA = 0.5, weightB = 0.5) {
  if (!isValidVector(vectorA) || !isValidVector(vectorB)) {
    throw new TypeError("mergeVectors: invalid vector shape");
  }

  const keys = new Set([...Object.keys(vectorA), ...Object.keys(vectorB)]);
  const merged = {};

  for (const key of keys) {
    const a = vectorA[key] ?? 0;
    const b = vectorB[key] ?? 0;
    merged[key] = Math.min(1, Math.max(0, a * weightA + b * weightB));
  }

  return merged;
}
