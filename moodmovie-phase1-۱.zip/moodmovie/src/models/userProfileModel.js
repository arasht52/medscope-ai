// Shape, factory, and validator for the persisted user profile object
// (storage key: moodmovie_user_profile). See emotionModel.js for the
// shared vector shape used by emotionVector and personalityVector.

import { createVector, isValidVector } from "./emotionModel.js";

/**
 * Build a user profile object with default/empty vectors and timestamps.
 * @param {Object} [params]
 * @param {Object<string, number>} [params.emotionVector]
 * @param {Object<string, number>} [params.personalityVector]
 * @returns {{emotionVector: Object, personalityVector: Object, createdAt: string, updatedAt: string}}
 */
export function createUserProfile({ emotionVector = {}, personalityVector = {} } = {}) {
  const now = new Date().toISOString();

  return {
    emotionVector: createVector(emotionVector),
    personalityVector: createVector(personalityVector),
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Validate a user profile object against the expected shape.
 * @param {*} profile
 * @returns {boolean}
 */
export function isValidUserProfile(profile) {
  if (!profile || typeof profile !== "object") return false;

  const { emotionVector, personalityVector, createdAt, updatedAt } = profile;

  const hasValidVectors = isValidVector(emotionVector) && isValidVector(personalityVector);
  const hasValidTimestamps =
    typeof createdAt === "string" &&
    !Number.isNaN(Date.parse(createdAt)) &&
    typeof updatedAt === "string" &&
    !Number.isNaN(Date.parse(updatedAt));

  return hasValidVectors && hasValidTimestamps;
}
