// Shape, factory, and validator for the explainable recommendation output
// returned by the recommendation engine (engine/recommend.js, added in a
// later phase). This is the single source of truth for that output shape.

import { isValidMovie } from "./movieModel.js";

/**
 * Build a normalized recommendation result object.
 * @param {Object} [params]
 * @param {Object} params.movie - a valid movie object (see movieModel.js)
 * @param {number} params.score - overall match score, 0–1
 * @param {string[]} [params.matchReasons]
 * @param {string[]} [params.warnings]
 * @param {number} [params.emotionalFit] - 0–1
 * @param {number} [params.personalityFit] - 0–1
 * @param {number} [params.safetyFit] - 0–1
 * @returns {Object}
 */
export function createRecommendation({
  movie,
  score,
  matchReasons = [],
  warnings = [],
  emotionalFit = 0,
  personalityFit = 0,
  safetyFit = 0,
} = {}) {
  return {
    movie,
    score,
    matchReasons: Array.isArray(matchReasons) ? [...matchReasons] : [],
    warnings: Array.isArray(warnings) ? [...warnings] : [],
    emotionalFit,
    personalityFit,
    safetyFit,
  };
}

/**
 * Validate a recommendation object against the required shape.
 * @param {*} recommendation
 * @returns {boolean}
 */
export function isValidRecommendation(recommendation) {
  if (!recommendation || typeof recommendation !== "object") return false;

  const { movie, score, matchReasons, warnings, emotionalFit, personalityFit, safetyFit } = recommendation;

  const isUnitInterval = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1;

  const hasValidMovie = isValidMovie(movie);
  const hasValidScore = isUnitInterval(score);
  const hasValidArrays =
    Array.isArray(matchReasons) &&
    matchReasons.every((reason) => typeof reason === "string") &&
    Array.isArray(warnings) &&
    warnings.every((warning) => typeof warning === "string");
  const hasValidFitScores = isUnitInterval(emotionalFit) && isUnitInterval(personalityFit) && isUnitInterval(safetyFit);

  return hasValidMovie && hasValidScore && hasValidArrays && hasValidFitScores;
}
