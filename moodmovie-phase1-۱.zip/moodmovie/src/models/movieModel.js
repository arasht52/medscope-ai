// Shape, factory, and validator for movie/series entries (movies.json,
// added in a later phase). Ensures every entry has the required fields
// before it enters the recommendation engine.
//
// Phase 1 simplified schema (per PM spec). Note on `watchContext`: the spec
// did not state whether this is a single value or a list. It is treated as
// an array (e.g. ["alone", "with_partner", "family"]) for consistency with
// the other multi-value tag fields (genres, moodTags, etc.) — flag with PM
// if a single string was intended instead.

const VALID_TYPES = ["movie", "series"];

// Numeric scoring fields, each expected to be a number from 0 to 10.
const SCORE_FIELDS = [
  "energy",
  "sadness",
  "violence",
  "fear",
  "hope",
  "humor",
  "complexity",
  "pacing",
  "romance",
];

// Fields that must be arrays.
const ARRAY_FIELDS = [
  "genres",
  "moodTags",
  "emotionalGoals",
  "personalityTags",
  "watchContext",
  "contentWarnings",
];

/**
 * Build a normalized movie object matching the Phase 1 schema.
 * Array fields default to []. Numeric score fields default to 0.
 * familyFriendly defaults to false (cautious default — not assumed safe
 * unless explicitly set). Required scalar fields with no safe default
 * (id, title, type, year, endingType, reason) are passed through as-is
 * (undefined if omitted), so isValidMovie correctly flags missing data
 * rather than the factory silently masking it.
 *
 * @param {Object} [params]
 * @param {string} params.id
 * @param {string} params.title
 * @param {"movie"|"series"} params.type
 * @param {number} params.year
 * @param {string[]} [params.genres]
 * @param {string[]} [params.moodTags]
 * @param {string[]} [params.emotionalGoals]
 * @param {string[]} [params.personalityTags]
 * @param {number} [params.energy] - 0–10
 * @param {number} [params.sadness] - 0–10
 * @param {number} [params.violence] - 0–10
 * @param {number} [params.fear] - 0–10
 * @param {number} [params.hope] - 0–10
 * @param {number} [params.humor] - 0–10
 * @param {number} [params.complexity] - 0–10
 * @param {number} [params.pacing] - 0–10
 * @param {number} [params.romance] - 0–10
 * @param {boolean} [params.familyFriendly]
 * @param {string} params.endingType
 * @param {string[]} [params.watchContext]
 * @param {string[]} [params.contentWarnings]
 * @param {string|null} [params.posterUrl]
 * @param {number|null} [params.runtimeMinutes]
 * @param {string} params.reason
 * @returns {Object}
 */
export function createMovie({
  id,
  title,
  type,
  year,
  genres = [],
  moodTags = [],
  emotionalGoals = [],
  personalityTags = [],
  energy = 0,
  sadness = 0,
  violence = 0,
  fear = 0,
  hope = 0,
  humor = 0,
  complexity = 0,
  pacing = 0,
  romance = 0,
  familyFriendly = false,
  endingType,
  watchContext = [],
  contentWarnings = [],
  posterUrl = null,
  runtimeMinutes = null,
  reason,
} = {}) {
  return {
    id,
    title,
    type,
    year,
    genres: Array.isArray(genres) ? [...genres] : [],
    moodTags: Array.isArray(moodTags) ? [...moodTags] : [],
    emotionalGoals: Array.isArray(emotionalGoals) ? [...emotionalGoals] : [],
    personalityTags: Array.isArray(personalityTags) ? [...personalityTags] : [],
    energy,
    sadness,
    violence,
    fear,
    hope,
    humor,
    complexity,
    pacing,
    romance,
    familyFriendly,
    endingType,
    watchContext: Array.isArray(watchContext) ? [...watchContext] : [],
    contentWarnings: Array.isArray(contentWarnings) ? [...contentWarnings] : [],
    posterUrl,
    runtimeMinutes,
    reason,
  };
}

/**
 * Validate a movie object against the Phase 1 schema.
 * @param {*} movie
 * @returns {boolean}
 */
export function isValidMovie(movie) {
  if (!movie || typeof movie !== "object") return false;

  const isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
  const isPlainString = (value) => typeof value === "string";
  const isScore = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 10;
  const isArray = (value) => Array.isArray(value);

  const hasRequiredScalars =
    isNonEmptyString(movie.id) &&
    isNonEmptyString(movie.title) &&
    VALID_TYPES.includes(movie.type) &&
    typeof movie.year === "number" &&
    Number.isFinite(movie.year) &&
    typeof movie.familyFriendly === "boolean" &&
    isPlainString(movie.endingType) &&
    isPlainString(movie.reason);

  const hasValidArrays = ARRAY_FIELDS.every((field) => isArray(movie[field]));

  const hasValidScores = SCORE_FIELDS.every((field) => isScore(movie[field]));

  const hasValidOptionalFields =
    (movie.posterUrl === null || isPlainString(movie.posterUrl)) &&
    (movie.runtimeMinutes === null || (typeof movie.runtimeMinutes === "number" && Number.isFinite(movie.runtimeMinutes)));

  return hasRequiredScalars && hasValidArrays && hasValidScores && hasValidOptionalFields;
}
