// Default scoring weights for the recommendation engine.
// Used by scoreMovies / applyFeedbackWeights (implemented in a later phase).
// Overridable per-user via settings.weightOverrides (moodmovie_settings).
// Weights are expected to sum to 1, but this module does not enforce that —
// validation belongs to the engine layer, not constants.

export const DEFAULT_SCORING_WEIGHTS = {
  emotion: 0.4,
  personality: 0.3,
  feedback: 0.2,
  safety: 0.1,
};
