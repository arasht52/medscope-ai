// Centralized route path strings.
// Single source of truth for router definitions and navigation links.
// No router is wired yet (added when pages are implemented) — values defined now
// so other modules can reference stable paths without circular dependencies later.

export const APP_ROUTES = {
  HOME: "/",
  MOOD_QUIZ: "/quiz/mood",
  PERSONALITY_QUIZ: "/quiz/personality",
  RESULTS: "/results",
  MOVIE_DETAIL: "/movie/:movieId",
  FEEDBACK: "/feedback/:movieId",
  FAVORITES: "/favorites",
  HISTORY: "/history",
  PROFILE: "/profile",
  SETTINGS: "/settings",
};
