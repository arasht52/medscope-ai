function App() {
  return (
    <div className="min-h-screen flex items-center justify-center text-center p-4">
      <p>راه‌اندازی فاز ۱ تکمیل شد. صفحات در فاز بعدی اضافه می‌شوند.</p>
    </div>
  );
}

export default App;
